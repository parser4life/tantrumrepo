#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @tantrumdev wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil
import urllib2,urllib
import re
import uservar
from datetime import date, datetime, timedelta
from resources.libs import wizard as wiz

CLEANONSTART    = wiz.getS('cleanonstart')
CLEANCACHE      = wiz.getS('clearcache')
CLEANCRASHLOGS  = wiz.getS('clearcrashlogs')
CLEANPACKAGES   = wiz.getS('clearpackages')
CLEANTHUMBS     = wiz.getS('clearoldthumbs')

if CLEANONSTART == 'true':
	if CLEANCACHE == 'true': wiz.log('[AUTO CLEAN ON START][Cache: on]'); wiz.clearCache()
	else: wiz.log('[AUTO CLEAN ON START][Cache: off]')
	if CLEANCRASHLOGS == 'true': wiz.log('[AUTO CLEAN ON START][Crash Logs: on]'); wiz.clearCrashLogs('startup')
	else: wiz.log('[AUTO CLEAN ON START][Crash Logs: off]')
	if CLEANPACKAGES == 'true': wiz.log('[AUTO CLEAN ON START][Packages: on]'); wiz.clearPackages('startup')
	else: wiz.log('[AUTO CLEAN ON START][Packages: off]')
	if CLEANTHUMBS == 'true': wiz.log('[AUTO CLEAN ON START][Old Thumbnails: on]'); wiz.clearOldThumbs('startup')
	else: wiz.log('[AUTO CLEAN ON START][Old THumbnails: off]')
else: wiz.log('[AUTO CLEAN ON START: off]')

